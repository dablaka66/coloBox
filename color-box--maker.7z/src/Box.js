import react from "react";

function Box (id,color,w,h,handleRemove){
    const remove = () => handleRemove(id);
    

    return (
    <div className="Box">
        <div
            id={id}
            style={{
                height: `${h}px`,
                width: `${w}px`,
                backgroundColor: `${color}`
              }}
            >
            <button onClick={remove}
            >X</button>
        </div>
    </div>

    );

    
}

export default Box;