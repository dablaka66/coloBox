import { useState } from "react";
import Box from "./Box.js";
import NewForm from "./Newform.js";

function BoxList() {

  const [boxesList, setBoxList] = useState([]);

  const addBox = (obj) => {
    const {color,width,height} = obj;
    console.log("este es: " + color + "  " + width  + "  " + height )
    setBoxList((boxesList) => [...boxesList, obj]);
  };

  const boxparameters = {
    id: "",
    backgroundcolor: "",
    width: "",
    height: "",
  };
  

  

  const handleRemove = (e) => {
    setBoxList(boxesList.filter((box) => box.id != e.id));
  };
  

  const boxes =
  boxesList.map((box) => {
      return <Box
        id={box.id}
        backgroundColor={box.color}
        width={box.width}
        height={box.height}
      />
    });
  console.log("boxes",boxes);
  return (
    <div className="container">
      <NewForm addBox={addBox} />
         <div className="boxList">{boxes}</div>
    </div>
  );
}

export default BoxList;
