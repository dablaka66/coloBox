import BoxList from './BoxList.js';
import './App.css';
import Aform from './Aform.js';


function App() {
  return (
    <div className="App">
     <BoxList /> 
    </div>
  );
}

export default App;
//https://mail.google.com/mail/u/0?ui=2&ik=0e2c1276f0&attid=0.1&permmsgid=msg-f:1770703946194864313&th=1892cddb8353c8b9&view=att&disp=safe&realattid=f_ljrleix20